# 当天 commit Code Review 套件

把"夜间 token 用量 KPI"刷成**真实产出**：每晚用一个 headless DSH 会话 + workflow 工具，
审**当天的提交**——每个提交一个独立 subagent 做 code review，报告落盘即审计证据。
适用团队：**没有 PR、直接在主分支提交**——夜间自动 review 就是唯一的代码把关。

## 逻辑（就三步）

```
cron 触发
  └─ nightly-review.sh
       ├─ flock 防重入
       ├─ git fetch 所有仓库
       ├─ 找当天的提交：git log --since=today origin/main（旧的在前）→ 待审清单 queue.txt
       ├─ pnpm dsh --profile headless "任务"（失败自动重试，直到审完或次数用尽）
       │     └─ workflow 扇出：每个提交一个 subagent ← 单项失败隔离 + 一次自动重试
       │           └─ 写 reports/<日期>/<repo>-<短sha>.md + 返回结构化 JSON
       └─ 汇总 → summary.md（纯脚本，不花 token）
```

**核心不变量：`reports/<日期>/<repo>-<短sha>.md` 落盘 = 该提交审完。**
崩溃/超时后重跑，自动跳过已有报告的项——重跑即续跑，最多损失一个正在审的提交。

## 目录结构

```
nightly-review/
├── nightly-review.sh      # 主入口（cron 调用）
├── task-prompt.txt        # headless 任务提示词（内含 workflow 脚本模板；{{TODAY}} 由脚本替换为当天日期）
├── queue.txt              # 当天待审清单（每次运行重新生成，勿手改）
├── summary.md             # 当天汇总
├── logs/                  # run.log + 每次运行的 agent 报告
├── reports/
│   └── 2026-08-21/        # 按天分目录，每提交一份审查报告（= 完成标记 = KPI 证据）
└── state/
    └── repos.map          # repo名 → 绝对路径（自动生成）
```

## 安装与配置

1. 编辑 `nightly-review.sh` 顶部配置：

   - `DSH_REPO`：公司 DSH 源码目录（默认 `/Users/lee/code/deepseek-harness`，按公司机器改）；
   - `REPOS`：要审查的仓库绝对路径（**必填**，留空会拒绝运行）；
   - `BRANCH`：审查的分支（默认 `main`）；
   - `SINCE`：找哪天的提交，默认 `today`（当天 0 点至今）；**cron 设在凌晨、想审前一天就设 `SINCE=yesterday`**，或 `SINCE="24 hours ago"`；
   - `MAX_COMMITS_PER_RUN`：单次最多审多少个（默认 50，防 token 爆炸，可调大）。

2. 公司机器上把模型插件装进 headless profile（公司模型是插件访问、没有 key）：

   ```bash
   cd <公司 DSH 目录>
   pnpm dsh plugin --profile headless add <公司插件名>
   pnpm dsh --profile headless "你好，回复OK"    # 验证能调通模型
   ```

3. 首次手动验证（可重复跑，已审的会自动跳过）：

   ```bash
   chmod +x /路径/nightly-review/nightly-review.sh
   /路径/nightly-review/nightly-review.sh
   cat /路径/nightly-review/summary.md
   ls /路径/nightly-review/reports/
   ```

4. 上 cron（macOS/Linux；Windows 用 Git Bash/WSL 跑，或任务计划程序调 git-bash）：

   ```
   # crontab -e
   30 23 * * * /路径/nightly-review/nightly-review.sh >> /路径/nightly-review/logs/cron.log 2>&1
   ```

   （放 23:30 审"当天"最自然；凌晨跑记得把 `SINCE` 设为 `yesterday`。）

## KPI 与成本

- 夜间（DeepSeek 官方低谷时段，约 5 折）跑真实 review，成本天然更低——这个 KPI 本来就是
  推动错峰利用，把真实工作挪过去就是"合理刷"。
- 每份提交审查报告都是真实产出和审计证据：审了哪个提交、发现什么问题、结论如何，全可追溯。
- 用量/成本统计：DSH 会话持久化在 `$DSH_REPO/.sessions`（JSONL/zstd），可用社区插件
  [dsh-whale-report](https://github.com/SenmuuuuW/dsh-whale-report) 或
  [dsh-usage-billing](https://github.com/940842546/dsh-usage-billing) 从会话日志算出 token
  与费用明细，直接对上"夜间 token 用量"口径。
- 省钱可选：审查 subagent 只读 commit diff、超过 800 行只审高风险文件（模板已内置）；
  若 headless profile 注册了 flash 模型，可在 workflow 脚本的 `review()` opts 里加
  `model: 'deepseek-v4-flash'`（主会话用 pro 调度、审查用 flash，成本可降一大截）。

## 常见问题

- **找不到提交**：确认 `BRANCH` 和 `SINCE` 配置正确、`git fetch` 成功（当天没提交的话脚本
  会显示"发现 0 个"，直接不跑 agent，不花 token）。
- **凌晨跑想审前一天**：`SINCE=yesterday`。
- **某天整晚失败没审**：当天窗口已过，手动补一次：`SINCE="2 days ago" ./nightly-review.sh`。
- **报告被删会重审**：报告即完成标记，删了就会重新审（幂等但不免费，别删）。
- **换审查规则**：改 `task-prompt.txt` 里 review 提示词和 schema 即可，不用动脚本。
