#!/usr/bin/env bash
# 当天 commit Code Review —— 主入口（cron 调用，全程无人值守）
#
# 逻辑（就三步）：找当天的提交 → 每个提交一个 subagent 审查 → 写报告。
#   - 窗口默认"今天"（git log --since=today），想审昨天就设 SINCE=yesterday
#   - 报告放 reports/<日期>/，一份报告 = 一个提交审完；重跑跳过已有报告的项
#   - 没有跨夜队列/增量状态，简单直接
#
# 用法：chmod +x nightly-review.sh 后配置 REPOS，先手动跑一次验证，再上 cron。

set -euo pipefail

# ---------- 配置（按你的环境改） ----------
DSH_REPO="${DSH_REPO:-/Users/lee/code/deepseek-harness}"   # DSH 源码目录（pnpm dsh 在这里执行）
WORKDIR="$(cd "$(dirname "$0")" && pwd)"                   # 本脚本所在目录
REPOS=(                                                    # 要审查的仓库（绝对路径）
  # /Users/you/project-a
  # /Users/you/project-b
)
BRANCH="${BRANCH:-main}"     # 审查哪个分支（默认 main）
SINCE="${SINCE:-today}"      # 找哪天起的提交：today=当天 0 点至今；凌晨跑想要前一天就设 yesterday
MAX_COMMITS_PER_RUN="${MAX_COMMITS_PER_RUN:-50}"   # 单次最多审多少个（防 token 爆炸）
MAX_ATTEMPTS=3               # 同一晚最多重试 headless 运行的次数
RETRY_BACKOFF=300            # 重试基础间隔（秒），按次数递增

TODAY="$(date '+%Y-%m-%d')"
REPORT_DIR="$WORKDIR/reports/$TODAY"
mkdir -p "$WORKDIR"/{logs,state} "$REPORT_DIR"
log() { echo "[$(date '+%F %T')] $*" | tee -a "$WORKDIR/logs/run.log"; }

# ---------- 0. 防重入：同一时间只允许一个实例 ----------
exec 9>"$WORKDIR/.lock"
flock -n 9 || { log "另一个实例正在运行，退出"; exit 0; }

[ "${#REPOS[@]}" -gt 0 ] || { log "REPOS 为空，请先在脚本里配置仓库路径"; exit 1; }

# ---------- 1. 拉取所有仓库（agent 只读本地 git 对象，不做网络操作） ----------
for r in "${REPOS[@]}"; do
  [ -d "$r/.git" ] || { log "跳过（不是 git 仓库）: $r"; continue; }
  log "fetch $r"
  git -C "$r" fetch --all --prune >/dev/null 2>&1 || log "  fetch 失败（继续）: $r"
done

# repo 名 → 绝对路径 映射，供 task-prompt 里的 agent 解析
: > "$WORKDIR/state/repos.map"
for r in "${REPOS[@]}"; do
  [ -d "$r/.git" ] && echo "$(basename "$r") $r" >> "$WORKDIR/state/repos.map"
done

# ---------- 2. 发现当天的提交（旧的在前），跳过已有报告的，生成待审清单 ----------
: > "$WORKDIR/queue.txt"
for r in "${REPOS[@]}"; do
  [ -d "$r/.git" ] || continue
  repo_name="$(basename "$r")"
  git -C "$r" log --since="$SINCE" --reverse --format='%H' "origin/$BRANCH" 2>/dev/null \
    | while read -r full; do
        short="${full:0:12}"
        [ -f "$REPORT_DIR/${repo_name}-${short}.md" ] && continue
        printf '%s|%s|%s\n' "$repo_name" "$short" "$full"
      done \
    | head -n "$MAX_COMMITS_PER_RUN" >> "$WORKDIR/queue.txt"
done
n="$(wc -l < "$WORKDIR/queue.txt" | tr -d ' ')"
log "窗口[$SINCE] 发现 $n 个待审提交（报告目录 $REPORT_DIR）"

# ---------- 3. 执行：headless 跑 workflow（多 subagent 扇出），直到审完或次数用尽 ----------
attempt=1
while [ "$attempt" -le "$MAX_ATTEMPTS" ]; do
  pending="$(while IFS='|' read -r r short _; do
    [ -f "$REPORT_DIR/${r}-${short}.md" ] || echo x
  done < "$WORKDIR/queue.txt" | wc -l | tr -d ' ')"
  [ "$pending" -gt 0 ] || { log "全部完成"; break; }

  task="$(sed "s/{{TODAY}}/$TODAY/g" "$WORKDIR/task-prompt.txt")"
  log "第 $attempt 次尝试：剩余 $pending 项"
  if ( cd "$DSH_REPO" && pnpm dsh --profile headless "$task" ); then
    log "本次运行完成（是否有剩余以报告为准）"
  else
    rc=$?
    log "headless 运行失败（exit $rc），$((attempt * RETRY_BACKOFF)) 秒后重试"
    sleep "$((attempt * RETRY_BACKOFF))"
  fi
  attempt=$((attempt + 1))
done

# ---------- 4. 汇总（纯脚本，不花 token） ----------
{
  echo "# 当天 commit Review 汇总（$TODAY）"
  echo
  echo "## 已审（$REPORT_DIR）"
  for f in "$REPORT_DIR"/*.md; do
    [ -e "$f" ] || continue
    echo "- [$(basename "$f" .md)]($f)"
  done
  echo
  echo "## 未完成"
  while IFS='|' read -r r short _; do
    [ -f "$REPORT_DIR/${r}-${short}.md" ] || echo "- ${r} ${short}"
  done < "$WORKDIR/queue.txt"
} > "$WORKDIR/summary.md"
log "汇总已写入 summary.md"

log "完成"
